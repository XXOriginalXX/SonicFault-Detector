import React, { useState, useRef } from 'react';
import { ArrowLeft, Mic, Upload, Signal, Engine, Play, Pause, AlertCircle } from './icons/CustomIcons';
import { uploadAudio, analyzeResult } from '../services/api';

interface AnalyzePageProps {
  onBack: () => void;
  isBackendConnected: boolean;
}

type AnalysisMode = 'live' | 'upload';

const AnalyzePage: React.FC<AnalyzePageProps> = ({ onBack, isBackendConnected }) => {
  const [mode, setMode] = useState<AnalysisMode | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<analyzeResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      setAnalysisResult(null);
    }
  };

  const handleAnalyzeFile = async () => {
    if (!uploadedFile || !isBackendConnected) return;

    setIsAnalyzing(true);
    try {
      const result = await uploadAudio(uploadedFile);
      setAnalysisResult(result);
    } catch (error) {
      console.error('Analysis failed:', error);
      setAnalysisResult({
        status: 'error',
        message: 'Analysis failed. Please try again.'
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // TODO: Implement WebSocket connection for live audio
  };

  if (!mode) {
    return (
      <div className="analyze-page">
        <div className="analyze-background">
          <div className="waveform-container">
            {[...Array(20)].map((_, i) => (
              <div key={i} className={`waveform-bar bar-${i + 1}`}></div>
            ))}
          </div>
        </div>

        <div className="analyze-container">
          <button className="back-button" onClick={onBack}>
            <ArrowLeft />
          </button>

          <div className="mode-selector">
            <div className="selector-header">
              <Engine />
              <h1>Select Analysis Mode</h1>
              <p>Choose how you want to analyze your vehicle's audio</p>
            </div>

            <div className="mode-options">
              <button
                className="mode-option"
                onClick={() => setMode('live')}
                disabled={!isBackendConnected}
              >
                <div className="mode-icon live-icon">
                  <Mic />
                  <div className="pulse-ring"></div>
                </div>
                <h3>Live Analysis</h3>
                <p>Real-time engine sound analysis through microphone</p>
                <div className="mode-glow live-glow"></div>
              </button>

              <button
                className="mode-option"
                onClick={() => setMode('upload')}
                disabled={!isBackendConnected}
              >
                <div className="mode-icon upload-icon">
                  <Upload />
                </div>
                <h3>File Upload</h3>
                <p>Analyze pre-recorded MP3 or WAV audio files</p>
                <div className="mode-glow upload-glow"></div>
              </button>
            </div>

            {!isBackendConnected && (
              <div className="connection-warning">
                <AlertCircle />
                <span>Backend connection required for analysis</span>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="analyze-page">
      <div className="analyze-background">
        <div className="analyzer-grid">
          {[...Array(16)].map((_, i) => (
            <div key={i} className={`analyzer-cell cell-${i + 1}`}>
              <Signal />
            </div>
          ))}
        </div>
      </div>

      <div className="analyze-container">
        <div className="analyze-header">
          <button className="back-button" onClick={() => setMode(null)}>
            <ArrowLeft />
          </button>
          
          <h1>{mode === 'live' ? 'Live Audio Analysis' : 'File Analysis'}</h1>
        </div>

        <div className="analyze-content">
          {mode === 'live' && (
            <div className="live-analysis">
              <div className="recording-interface">
                <div className={`recording-visualizer ${isRecording ? 'active' : ''}`}>
                  <div className="mic-container">
                    <Mic />
                    {isRecording && <div className="recording-pulse"></div>}
                  </div>
                </div>
                
                <button
                  className={`record-button ${isRecording ? 'recording' : ''}`}
                  onClick={toggleRecording}
                >
                  {isRecording ? <Pause /> : <Play />}
                  <span>{isRecording ? 'STOP RECORDING' : 'START RECORDING'}</span>
                </button>
                
                <p className="recording-status">
                  {isRecording ? 'Analyzing engine sound...' : 'Press to start live analysis'}
                </p>
              </div>
            </div>
          )}

          {mode === 'upload' && (
            <div className="upload-analysis">
              <div className="upload-area">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".mp3,.wav"
                  onChange={handleFileUpload}
                  style={{ display: 'none' }}
                />
                
                <div
                  className="upload-zone"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload />
                  <h3>Drop your audio file here</h3>
                  <p>Supports MP3 and WAV formats (max 30 seconds)</p>
                  <button className="upload-button">Select File</button>
                </div>
              </div>

              {uploadedFile && (
                <div className="file-info">
                  <div className="file-details">
                    <Signal />
                    <span>{uploadedFile.name}</span>
                    <span className="file-size">
                      {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                    </span>
                  </div>
                  
                  <button
                    className="analyze-button"
                    onClick={handleAnalyzeFile}
                    disabled={isAnalyzing}
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="spinner"></div>
                        <span>ANALYZING...</span>
                      </>
                    ) : (
                      <>
                        <Engine />
                        <span>ANALYZE AUDIO</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          )}

          {analysisResult && (
            <div className="results-section">
              <div className="results-header">
                <Engine />
                <h2>Analysis Results</h2>
              </div>
              
              {analysisResult.status === 'success' && analysisResult.result && (
                <div className="results-content">
                  <div className="primary-result">
                    <h3>Detected Issue</h3>
                    <div className="issue-badge">
                      {analysisResult.result.detected_issue}
                    </div>
                  </div>
                  
                  <div className="confidence-scores">
                    <h3>Confidence Scores</h3>
                    <div className="scores-grid">
                      {Object.entries(analysisResult.result.confidence_scores).map(([issue, confidence]) => (
                        <div key={issue} className="score-item">
                          <span className="issue-name">{issue}</span>
                          <div className="confidence-bar">
                            <div 
                              className="confidence-fill"
                              style={{ width: `${confidence}%` }}
                            ></div>
                          </div>
                          <span className="confidence-value">{confidence.toFixed(1)}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              
              {analysisResult.status === 'error' && (
                <div className="error-result">
                  <AlertCircle />
                  <p>{analysisResult.message}</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalyzePage;